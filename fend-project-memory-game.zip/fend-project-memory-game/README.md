# Memory Game Project
Memory has long been a favorite game for all generations. It is easy to play, in fact it is so simple that really young children can play with ease.

It requires observation, concentration and a good memory to win.

Now it is available to play on the web page.

## Table of Contents

* [Instructions](#instructions)
* [Contributing](#contributing)

## Instructions

The starter project has some HTML and CSS styling to display the Memory Game project.to run the game open the `index.html` chose the cards and if they match it'll be green if not it'll be black and hidden

to change the color of card or add more functions open `js/app.js` 

make sure you download sweetalert2 frist,the win message will not display if you have not download it 



## Contributing
This game does not tolerate any contribution, it is udacity project for nano degree


## SweetAlert2

to Appear the pop up message you need to [download](https://sweetalert2.github.io) the library .
