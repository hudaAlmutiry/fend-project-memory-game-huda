/*
 * Create a list that holds all of your cards
 */
let card = document.getElementsByClassName("card");
let cards = [...card];

// for count the move in the game 
let moves = 0;
let counter = document.querySelector('.moves');

// for the rating stars 
let star = document.getElementsByClassName("fa fa-star");
let stars = [...star];

// array for the icons to shuffle them 
let icons = ["fa fa-diamond", "fa fa-paper-plane-o", "fa fa-anchor", "fa fa-bolt", "fa fa-cube", "fa fa-anchor", "fa fa-leaf",
  "fa fa-bicycle", "fa fa-diamond", "fa fa-bomb", "fa fa-leaf", "fa fa-bomb", "fa fa-bolt", "fa fa-bicycle", "fa fa-paper-plane-o", "fa fa-cube"];

let matchcard = [];// array to save the match cards
let openCards = [];// array to save the open cards i will use it to check two cards if they match or not that mean the length is 2 

let interval;// for start the timer
let scd, min, hour;// for the time method
for (var i = 0; i < cards.length; i++) {
  cards[i].addEventListener("click", displayCard);// event if the card was clicked go to --> displayCard

};


// display  card when it is click 
function displayCard() {
  // check that there no card open or show 
  this.classList.toggle("open");
  this.classList.toggle("show");

  let self = this;// the clicked card 
  openAndCheck(self);// send it to open and check method
  starttime();
}
// open the cards and check if it is match or not 
function openAndCheck(self) {
  openCards.push(self);
  // clear the not match class from the cards
  openCards[0].classList.remove("not-matching");
  openCards[1].classList.remove("not-matching");
  let length = openCards.length;
  if (length === 2) {// if the 2 cards are open check if there is matching by if conditions 
    //move Counter increase
    moves++;

    if (openCards[0].type === openCards[1].type) {
      // if two card match add class match and remove the show and open class and push the cards to match card array 
      openCards[0].classList.add("match");
      openCards[1].classList.add("match");
      openCards[0].classList.remove("show", "open");
      openCards[1].classList.remove("show", "open");
      matchcard.push(openCards[0]);
      matchcard.push(openCards[1]);
      openCards.length = 0;

    } else {
      // if two card not match add class not-match and remove the show and open class 

      openCards[0].classList.add("not-matching");
      openCards[1].classList.add("not-matching");
      openCards[0].classList.remove("show", "open");
      openCards[1].classList.remove("show", "open");
      openCards.length = 0;
    }

  }

  checkTheend();// call method checkTheend to check if it is the last two cards

}
// method for counting the moves and for  the star rating 
function Mymoves() {
  counter.innerHTML = moves + "&nbsp Moves   &nbsp";// show the moves in the html 
  /* in the star rating (for me ):
  3 Stars if:moves less than 10
  2 Stars if:moves less than 13 and bigger than 11
  1 Stars if:moves  less than 20 and bigger than 15
  0 Stars if:moves  bigger than 20
  */

  if ((moves >= 11) && (moves <= 13)) {
    stars[0].remove();
  }
  if (moves > 15 && moves < 20) {
    stars[0].remove();
    stars[1].remove();
  }
  if (moves >= 20) {
    stars[0].remove();
    stars[1].remove();
    stars[2].remove();
  }

}


function starttime() {
  if (moves === 1) {// start the timer after click the frist card
    scd = 0;
    min = 0;
    interval = setInterval(function () {
      document.querySelector("#seconds").innerHTML = min + ":" + scd;
      scd++;
      if (scd == 60) {
        min++;
        scd = 0;
      }

    }, 1000);

  }
}

// Shuffle function from http://stackoverflow.com/a/2450976
function shuffle(array) {
  var currentIndex = array.length, temporaryValue, randomIndex;

  while (currentIndex !== 0) {
    randomIndex = Math.floor(Math.random() * currentIndex);
    currentIndex -= 1;
    temporaryValue = array[currentIndex];
    array[currentIndex] = array[randomIndex];
    array[randomIndex] = temporaryValue;
  }

  return array;


}


// for restrant the game 

function restrant() {
  // Shuffles icon name 
  icons = shuffle(icons);

  // clear  the classes from each card and assign the shuffled icons to the card 
  for (let i = 0; i < cards.length; i++) {
    let thisicon = icons[i];
    cards[i].classList.remove("open");
    cards[i].classList.remove("show");
    cards[i].classList.remove("match");
    cards[i].classList.remove("not-matching");
    cards[i].firstElementChild.className = thisicon;// rename the class of i element in the li
    cards[i].type = thisicon;// rename the type for the li element in the ul
  }

  setTimeout(() => window.location.reload(), 3000); // reload the page after 3 seconds for restart the moves and rating and timer 
}

// to check if the user win the game and all cards match 
function checkTheend() {
  if (matchcard.length === 16) {
    clearTimeout(interval);// stop the timer

    Swal.fire({
      title: 'This game does not tolerate any contribution' + '  the time is  ' + min + ':' + scd + "  and your Moves " + moves + "     play again ?",// print the time and the rating
      width: 600,
      padding: '3em',
      background: '#fff url(./img/geometry2.png)',
      backdrop: `
      url("./img/stars.gif")
      center left
      repeat
    `
    }).then(// after that call the method restrant to start again
      restrant()
    )

  }
  Mymoves();// calculate the rating stars
}





